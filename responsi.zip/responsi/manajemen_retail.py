import tkinter as tk
from tkinter import ttk, messagebox
import mysql.connector
from datetime import datetime
import decimal

class Database:
    def __init__(self):
        self.connection = mysql.connector.connect(
            host="localhost",
            user="root",
            password="",
            database="retail_db"
        )
        self.cursor = self.connection.cursor()
        self.setup_database()
    
    def setup_database(self):
        self.cursor.execute("""
            CREATE TABLE IF NOT EXISTS produk (
                id INT AUTO_INCREMENT PRIMARY KEY,
                nama VARCHAR(100) NOT NULL,
                harga DECIMAL(10,2) NOT NULL
            )
        """)
        
        self.cursor.execute("""
            CREATE TABLE IF NOT EXISTS transaksi (
                id INT AUTO_INCREMENT PRIMARY KEY,
                id_produk INT,
                jumlah INT NOT NULL,
                total_harga DECIMAL(10,2) NOT NULL,
                tanggal_transaksi DATE NOT NULL,
                FOREIGN KEY (id_produk) REFERENCES produk(id)
            )
        """)
        self.connection.commit()

class RetailApp:
    def __init__(self, root):
        self.root = root
        self.root.title("Aplikasi Retail - CRUD")
        self.root.geometry("800x600")
        self.db = Database()
        
        # Variabel untuk menyimpan ID produk yang sedang diedit
        self.selected_produk_id = None
        
        # Setup UI
        self.setup_ui()
        
        # Load data awal
        self.refresh_produk_list()
        self.refresh_transaksi_list()

    def setup_ui(self):
        # Notebook untuk tab
        notebook = ttk.Notebook(self.root)
        notebook.pack(pady=10, expand=True, fill='both')
        
        # Tab Produk
        produk_frame = ttk.Frame(notebook)
        notebook.add(produk_frame, text="Manajemen Produk")
        
        # Form Produk
        form_frame = ttk.LabelFrame(produk_frame, text="Form Produk")
        form_frame.pack(padx=5, pady=5, fill='x')
        
        ttk.Label(form_frame, text="Nama Produk:").grid(row=0, column=0, padx=5, pady=5)
        self.nama_produk_var = tk.StringVar()
        ttk.Entry(form_frame, textvariable=self.nama_produk_var).grid(row=0, column=1, padx=5, pady=5)
        
        ttk.Label(form_frame, text="Harga:").grid(row=1, column=0, padx=5, pady=5)
        self.harga_produk_var = tk.StringVar()
        ttk.Entry(form_frame, textvariable=self.harga_produk_var).grid(row=1, column=1, padx=5, pady=5)
        
        # Tombol Produk
        button_frame = ttk.Frame(form_frame)
        button_frame.grid(row=2, column=0, columnspan=2, pady=10)
        
        ttk.Button(button_frame, text="Tambah", command=self.tambah_produk).pack(side=tk.LEFT, padx=5)
        ttk.Button(button_frame, text="Update", command=self.update_produk).pack(side=tk.LEFT, padx=5)
        ttk.Button(button_frame, text="Delete", command=self.delete_produk).pack(side=tk.LEFT, padx=5)
        ttk.Button(button_frame, text="Clear", command=self.clear_form_produk).pack(side=tk.LEFT, padx=5)
        
        # Tabel Produk
        self.produk_tree = ttk.Treeview(produk_frame, columns=("ID", "Nama", "Harga"), show="headings")
        self.produk_tree.heading("ID", text="ID")
        self.produk_tree.heading("Nama", text="Nama Produk")
        self.produk_tree.heading("Harga", text="Harga")
        self.produk_tree.pack(padx=5, pady=5, fill='both', expand=True)
        
        # Binding untuk select produk
        self.produk_tree.bind('<<TreeviewSelect>>', self.on_select_produk)
        
        # Tab Transaksi
        transaksi_frame = ttk.Frame(notebook)
        notebook.add(transaksi_frame, text="Transaksi")
        
        # Form Transaksi
        form_transaksi = ttk.LabelFrame(transaksi_frame, text="Form Transaksi")
        form_transaksi.pack(padx=5, pady=5, fill='x')
        
        ttk.Label(form_transaksi, text="Pilih Produk:").grid(row=0, column=0, padx=5, pady=5)
        self.produk_combo = ttk.Combobox(form_transaksi, state="readonly")
        self.produk_combo.grid(row=0, column=1, padx=5, pady=5)
        
        ttk.Label(form_transaksi, text="Jumlah:").grid(row=1, column=0, padx=5, pady=5)
        self.jumlah_var = tk.StringVar()
        ttk.Entry(form_transaksi, textvariable=self.jumlah_var).grid(row=1, column=1, padx=5, pady=5)
        
        # Tombol Transaksi
        ttk.Button(form_transaksi, text="Buat Transaksi", 
                  command=self.buat_transaksi).grid(row=2, column=0, columnspan=2, pady=10)
        
        # Tabel Transaksi
        self.transaksi_tree = ttk.Treeview(transaksi_frame, 
            columns=("ID", "Produk", "Jumlah", "Total", "Tanggal"), 
            show="headings")
        self.transaksi_tree.heading("ID", text="ID")
        self.transaksi_tree.heading("Produk", text="Produk")
        self.transaksi_tree.heading("Jumlah", text="Jumlah")
        self.transaksi_tree.heading("Total", text="Total Harga")
        self.transaksi_tree.heading("Tanggal", text="Tanggal")
        self.transaksi_tree.pack(padx=5, pady=5, fill='both', expand=True)

    def clear_form_produk(self):
        self.nama_produk_var.set("")
        self.harga_produk_var.set("")
        self.selected_produk_id = None

    def on_select_produk(self, event):
        selected_items = self.produk_tree.selection()
        if selected_items:
            item = selected_items[0]
            values = self.produk_tree.item(item)['values']
            self.selected_produk_id = values[0]
            self.nama_produk_var.set(values[1])
            self.harga_produk_var.set(values[2])

    def refresh_produk_list(self):
        # Clear existing items
        for item in self.produk_tree.get_children():
            self.produk_tree.delete(item)
        
        # Fetch and display products
        self.db.cursor.execute("SELECT * FROM produk ORDER BY id")
        for row in self.db.cursor.fetchall():
            self.produk_tree.insert("", "end", values=row)
        
        # Update produk combo
        self.db.cursor.execute("SELECT id, nama FROM produk")
        produk_list = self.db.cursor.fetchall()
        self.produk_combo['values'] = [f"{id} - {nama}" for id, nama in produk_list]

    def refresh_transaksi_list(self):
        # Clear existing items
        for item in self.transaksi_tree.get_children():
            self.transaksi_tree.delete(item)
        
        # Fetch and display transactions
        self.db.cursor.execute("""
            SELECT t.id, p.nama, t.jumlah, t.total_harga, t.tanggal_transaksi 
            FROM transaksi t 
            JOIN produk p ON t.id_produk = p.id
            ORDER BY t.tanggal_transaksi DESC
        """)
        for row in self.db.cursor.fetchall():
            self.transaksi_tree.insert("", "end", values=row)

    def tambah_produk(self):
        try:
            nama = self.nama_produk_var.get()
            harga = decimal.Decimal(self.harga_produk_var.get())
            
            if not nama or harga <= 0:
                messagebox.showerror("Error", "Nama produk harus diisi dan harga harus lebih dari 0")
                return
            
            self.db.cursor.execute(
                "INSERT INTO produk (nama, harga) VALUES (%s, %s)",
                (nama, harga)
            )
            self.db.connection.commit()
            
            self.clear_form_produk()
            self.refresh_produk_list()
            messagebox.showinfo("Sukses", "Produk berhasil ditambahkan")
            
        except (ValueError, decimal.InvalidOperation):
            messagebox.showerror("Error", "Harga harus berupa angka")
        except Exception as e:
            messagebox.showerror("Error", f"Terjadi kesalahan: {str(e)}")

    def update_produk(self):
        if not self.selected_produk_id:
            messagebox.showwarning("Peringatan", "Pilih produk yang akan diupdate")
            return
            
        try:
            nama = self.nama_produk_var.get()
            harga = decimal.Decimal(self.harga_produk_var.get())
            
            if not nama or harga <= 0:
                messagebox.showerror("Error", "Nama produk harus diisi dan harga harus lebih dari 0")
                return
            
            self.db.cursor.execute(
                "UPDATE produk SET nama = %s, harga = %s WHERE id = %s",
                (nama, harga, self.selected_produk_id)
            )
            self.db.connection.commit()
            
            self.clear_form_produk()
            self.refresh_produk_list()
            messagebox.showinfo("Sukses", "Produk berhasil diupdate")
            
        except (ValueError, decimal.InvalidOperation):
            messagebox.showerror("Error", "Harga harus berupa angka")
        except Exception as e:
            messagebox.showerror("Error", f"Terjadi kesalahan: {str(e)}")

    def delete_produk(self):
        if not self.selected_produk_id:
            messagebox.showwarning("Peringatan", "Pilih produk yang akan dihapus")
            return
        
        if messagebox.askyesno("Konfirmasi", "Yakin ingin menghapus produk ini?"):
            try:
                self.db.cursor.execute("DELETE FROM produk WHERE id = %s", (self.selected_produk_id,))
                self.db.connection.commit()
                
                self.clear_form_produk()
                self.refresh_produk_list()
                messagebox.showinfo("Sukses", "Produk berhasil dihapus")
                
            except mysql.connector.Error as e:
                if e.errno == 1451:  # Cannot delete or update a parent row: a foreign key constraint fails
                    messagebox.showerror("Error", "Tidak dapat menghapus produk karena masih ada transaksi terkait")
                else:
                    messagebox.showerror("Error", f"Terjadi kesalahan: {str(e)}")
            except Exception as e:
                messagebox.showerror("Error", f"Terjadi kesalahan: {str(e)}")

    def buat_transaksi(self):
        try:
            if not self.produk_combo.get():
                messagebox.showerror("Error", "Pilih produk terlebih dahulu")
                return
            
            id_produk = int(self.produk_combo.get().split(" - ")[0])
            jumlah = int(self.jumlah_var.get())
            
            if jumlah <= 0:
                messagebox.showerror("Error", "Jumlah harus lebih dari 0")
                return
            
            # Get product price
            self.db.cursor.execute("SELECT harga FROM produk WHERE id = %s", (id_produk,))
            harga = decimal.Decimal(self.db.cursor.fetchone()[0])
            
            total_harga = harga * jumlah
            tanggal = datetime.now().date()
            
            self.db.cursor.execute(
                """INSERT INTO transaksi 
                   (id_produk, jumlah, total_harga, tanggal_transaksi) 
                   VALUES (%s, %s, %s, %s)""",
                (id_produk, jumlah, total_harga, tanggal)
            )
            self.db.connection.commit()
            
            # Clear form
            self.produk_combo.set("")
            self.jumlah_var.set("")
            
            self.refresh_transaksi_list()
            messagebox.showinfo("Sukses", "Transaksi berhasil dibuat")
            
        except ValueError:
            messagebox.showerror("Error", "Jumlah harus berupa angka")
        except Exception as e:
            messagebox.showerror("Error", f"Terjadi kesalahan: {str(e)}")

if __name__ == "__main__":
    root = tk.Tk()
    app = RetailApp(root)
    root.mainloop()