# Aplikasi Manajemen Retail - Produk & Transaksi

Aplikasi ini adalah sistem manajemen retail berbasis GUI menggunakan Tkinter dan MySQL. Aplikasi ini memungkinkan pengguna untuk mengelola produk dan transaksi secara efektif. Fitur utama dari aplikasi ini meliputi:

- **Manajemen Produk**: Menambahkan, mengupdate, dan menghapus produk.
- **Manajemen Transaksi**: Membuat transaksi pembelian produk oleh pelanggan.
- **Database MySQL**: Semua data produk dan transaksi disimpan di database MySQL.

## Fitur Utama

- **Manajemen Produk**:
  - Tambah produk baru
  - Update produk yang sudah ada
  - Hapus produk yang tidak digunakan lagi

- **Manajemen Transaksi**:
  - Pilih produk yang dibeli
  - Tentukan jumlah produk yang dibeli
  - Sistem secara otomatis menghitung total harga dan mencatat tanggal transaksi